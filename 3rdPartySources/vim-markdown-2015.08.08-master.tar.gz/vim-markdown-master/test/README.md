To run the tests, you must install [Vader](https://github.com/junegunn/vader.vim).

Vader and other plugins must be installed in the same directory as this repository.

Run the tests with:

    ./run-tests.sh
